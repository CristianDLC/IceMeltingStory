//as time goes on the ice cube melts 
var I1,I2,I3,I4,I5,I6;

function preload() {
  I1 = loadImage('Fire.png');
  I2 = loadImage('Ice1.png');
  I3 = loadImage('Ice2.png');
  I4 = loadImage('Ice3.png');
  I5 = loadImage('Ice4.png');
  I6 = loadImage('Ice5.png');
    soundFormats('mp3', 'ogg');
  soundFile = loadSound('fire-2.mp3');
}
let soundFile; //global variable to hold sound object


function setup() {
  createCanvas(400, 400);
  imageMode(CENTER);
  noCursor();
}

function draw() {
  background(255);
   var t1 = map(mouseX, 0, 400, 0, 255);
  var t2 = map(mouseX, 0, 100, 0, 255, 1);
  var t3;
   var t4;
   var t5;
   var t6;
  
  if (mouseX < 100){
    t3 = map(mouseX, 0, 100, 255, 0,1);
  }
  else{
    t3 = map(mouseX, 100, 200, 0, 255,1);
  }
  if (mouseX < 200){
   t4 = map(mouseX, 100, 200, 255, 0,1);
  }
  else {
   t4 = map(mouseX, 200, 300, 0, 255, 1);
  }
  if (mouseX <300){
      t5 = map(mouseX, 250, 350, 255, 0,1);
      }
  else {
    t5 = map(mouseX, 400,500, 0, 255, 1)
  }
   if (mouseX <350){
      t6 = map(mouseX, 300, 400, 255, 0,1);
      }
  else {
    t6 = map(mouseX, 400,500, 0, 255, 1)
  }
   if ( !soundFile.isPlaying()){
  soundFile.play();
  }
  tint(255, 255-t2);
  image(I2, width/2, height/2,100,100);
  
  tint(255, 255-t3);
  image(I3, width/2 +3, height/2 +5,140,130);
  
   tint(255, 255-t4);
  image(I4, width/2 +3, height/2 +10,145,130);
  
  tint(255, 255-t5);
  image(I5, width/2 +4, height/2 +6,140,140);
  
  tint(255, 255-t6);
  image(I6, width/2 +4, height/2 +8,140,140);
  
  noTint();
  image(I1, mouseX, mouseY,100,100);


}